
const page = () => {
  return (
    <div>
      THis is a Security Audit Page
    </div>
  );
};

export default page;